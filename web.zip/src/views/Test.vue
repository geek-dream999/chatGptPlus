<template>
  <div>
    {{ title }}
  </div>
</template>

<script setup>

import {ref} from "vue";

const title = ref('Test Page')

</script>

<style lang="stylus" scoped>
</style>