<template>
  <div class="app-background">
    <div class="mobile-setting container">
      <div class="title" style="padding-top: 50px">应用广场</div>
      <div class="title" style="padding-top: 200px">视频生成器即将开启……敬请期待</div>
    </div>
  </div>
</template>

<script setup>
</script>

<style lang="stylus">
@import "@/assets/css/mobile/apps.styl"
</style>
